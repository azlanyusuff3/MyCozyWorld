extends Node3D
## A synchronous phase machine keeps restarting and animation previews race-free.

const Builder = preload("res://scripts/hero_builder.gd")
const CLIPS: Array[StringName] = [&"idle", &"walk", &"attack", &"cast", &"hurt", &"victory", &"death"]
enum Phase { APPROACH, FIGHT, DEATH, CELEBRATE, PREVIEW }

var player: CozyHero
var enemy: CozyHero
var phase: Phase = Phase.APPROACH
var _waypoints: Array[Vector3] = []
var _elapsed: float = 0.0
var _status: Label
var completed_rounds: int = 0

func _ready() -> void:
	_build_board()
	_build_world()
	_build_hud()
	restart_demo()

func _build_board() -> void:
	var colors: Array[Color] = [Color("#A7C99A"), Color("#92B989")]
	for row: int in range(8):
		for column: int in range(8):
			var tile: MeshInstance3D = MeshInstance3D.new()
			tile.name = "Tile_%d_%d" % [column, row]
			var mesh: BoxMesh = BoxMesh.new()
			mesh.size = Vector3(0.95, 0.16, 0.95)
			tile.mesh = mesh
			var material: StandardMaterial3D = StandardMaterial3D.new()
			material.albedo_color = colors[(row + column) % 2]
			material.roughness = 0.8
			tile.material_override = material
			tile.position = _tile(column, row) + Vector3(0, -0.08, 0)
			add_child(tile)

func _build_world() -> void:
	var world: WorldEnvironment = WorldEnvironment.new()
	var environment: Environment = Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color("#BFD9E8")
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color("#DFEAF2")
	environment.ambient_light_energy = 0.7
	environment.glow_enabled = true
	world.environment = environment
	add_child(world)
	var sun: DirectionalLight3D = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, -25, 0)
	sun.light_color = Color("#FFF0D5")
	sun.light_energy = 1.3
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 30.0
	add_child(sun)
	var camera: Camera3D = Camera3D.new()
	add_child(camera)
	camera.position = Vector3(0, 11, 9)
	camera.look_at(Vector3(0, 0.2, -0.1), Vector3.UP)
	camera.fov = 45.0
	camera.current = true

func _build_hud() -> void:
	var layer: CanvasLayer = CanvasLayer.new()
	add_child(layer)
	var title: Label = Label.new()
	title.position = Vector2(24, 16)
	title.text = "COZY ARENA  /  BULWARK"
	title.add_theme_font_size_override("font_size", 26)
	title.add_theme_color_override("font_color", Color("#25394B"))
	layer.add_child(title)
	_status = Label.new()
	_status.position = Vector2(24, 52)
	_status.add_theme_color_override("font_color", Color("#25394B"))
	layer.add_child(_status)
	var keys: Label = Label.new()
	keys.text = "1 Idle   2 Walk   3 Attack   4 Cast   5 Hurt   6 Victory   7 Death   |   R Restart demo"
	keys.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	keys.position = Vector2(24, 676)
	keys.add_theme_font_size_override("font_size", 18)
	keys.add_theme_color_override("font_color", Color("#25394B"))
	layer.add_child(keys)

func restart_demo() -> void:
	# Immediate removal prevents old unit tweens from running another frame.
	if is_instance_valid(player):
		player.free()
	if is_instance_valid(enemy):
		enemy.free()
	player = Builder.build()
	player.name = "Bulwark"
	player.position = _tile(3, 6)
	add_child(player)
	enemy = Builder.build(Color("#B86C70"))
	enemy.name = "EnemyDummy"
	enemy.display_name = "Training Dummy"
	enemy.position = _tile(4, 1)
	enemy.rotation.y = PI
	add_child(enemy)
	_waypoints = [_tile(4, 6), _tile(4, 5), _tile(4, 4), _tile(4, 3), _tile(4, 2)]
	_elapsed = 0.0
	phase = Phase.APPROACH
	_status.text = "Demo: approaching one tile at a time. Press 1-7 for animation previews."

func _process(delta: float) -> void:
	if not is_instance_valid(player) or not is_instance_valid(enemy):
		return
	match phase:
		Phase.APPROACH:
			if player.state == CozyHero.State.IDLE:
				if not _waypoints.is_empty():
					var next_tile: Vector3 = _waypoints.pop_front()
					player.move_to(next_tile)
				else:
					phase = Phase.FIGHT
					_elapsed = 1.2
					_status.text = "Demo: sword strike every 1.2 seconds. Three hits to win."
		Phase.FIGHT:
			if enemy.state == CozyHero.State.DEAD:
				phase = Phase.DEATH
				_elapsed = 0.0
			else:
				_elapsed += delta
				if _elapsed >= 1.2 and player.attack(enemy):
					_elapsed = 0.0
		Phase.DEATH:
			_elapsed += delta
			if _elapsed >= 1.0:
				player.celebrate()
				phase = Phase.CELEBRATE
				_elapsed = 0.0
				_status.text = "Victory! Restarting in 2 seconds."
		Phase.CELEBRATE:
			_elapsed += delta
			if _elapsed >= 2.0:
				completed_rounds += 1
				restart_demo()

func _unhandled_key_input(event: InputEvent) -> void:
	var key: InputEventKey = event as InputEventKey
	if key == null or not key.pressed or key.echo:
		return
	if key.keycode == KEY_R:
		restart_demo()
	elif key.keycode >= KEY_1 and key.keycode <= KEY_7:
		phase = Phase.PREVIEW
		var clip: StringName = CLIPS[int(key.keycode - KEY_1)]
		player.play_preview(clip)
		_status.text = "Preview: %s. Demo paused; press R to restart." % clip

func _tile(column: int, row: int) -> Vector3:
	return Vector3(column - 3.5, 0, row - 3.5)

