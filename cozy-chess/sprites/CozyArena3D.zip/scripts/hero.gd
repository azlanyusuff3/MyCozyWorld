class_name CozyHero
extends Node3D
## Movement changes the root; animation changes only the visual Body subtree.

signal arrived
signal died
signal hit_landed(target: CozyHero)

const Animations = preload("res://scripts/hero_anims.gd")
enum State { IDLE, MOVING, ATTACKING, DEAD }

var state: State = State.IDLE
var display_name: String = "Bulwark"
var max_hp: int = 100
var hp: int = 100
var move_speed: float = 2.6
var animation_player: AnimationPlayer
var glow_material: StandardMaterial3D
var hp_label: Label3D
var _materials: Array[StandardMaterial3D] = []
var _colors: Array[Color] = []
var _move_tween: Tween
var _target: CozyHero
var _attack_time: float = 0.0
var _did_hit: bool = false

var flash_amount: float = 0.0:
	set(value):
		flash_amount = clampf(value, 0.0, 1.0)
		_update_materials()
var fade_amount: float = 0.0:
	set(value):
		fade_amount = clampf(value, 0.0, 1.0)
		_update_materials()
var glow_amount: float = 0.0:
	set(value):
		glow_amount = value
		if is_instance_valid(glow_material):
			glow_material.emission_enabled = value > 0.001
			glow_material.emission = Color("#E8B54A")
			glow_material.emission_energy_multiplier = value * 2.5

func _ready() -> void:
	animation_player = Animations.create(self)
	animation_player.animation_finished.connect(_animation_finished)
	hp_label = Label3D.new()
	hp_label.name = "HPBar"
	hp_label.position = Vector3(0, 1.93, 0)
	hp_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	hp_label.font_size = 32
	hp_label.pixel_size = 0.0025
	hp_label.outline_size = 6
	hp_label.no_depth_test = true
	add_child(hp_label)
	_update_hp()
	_play(&"idle")

func _process(delta: float) -> void:
	if state != State.ATTACKING:
		return
	_attack_time += delta
	if not _did_hit and _attack_time >= 0.34:
		_did_hit = true
		if is_instance_valid(_target) and _target.state != State.DEAD:
			if global_position.distance_to(_target.global_position) <= 1.35:
				_target.take_damage(34)
				hit_landed.emit(_target)

func register_material(material: StandardMaterial3D) -> void:
	_materials.append(material)
	_colors.append(material.albedo_color)

func _update_materials() -> void:
	for index: int in range(_materials.size()):
		var material: StandardMaterial3D = _materials[index]
		var color: Color = _colors[index].lerp(Color("#FF4242"), flash_amount * 0.85)
		color.a = 1.0 - fade_amount
		material.albedo_color = color
		material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA if fade_amount > 0.001 else BaseMaterial3D.TRANSPARENCY_DISABLED
	if is_instance_valid(hp_label):
		hp_label.modulate.a = 1.0 - fade_amount

func _update_hp() -> void:
	if not is_instance_valid(hp_label):
		return
	var filled: int = ceili(10.0 * hp / max_hp)
	hp_label.text = "%s\n[%s%s] %d/%d" % [display_name, "|".repeat(filled), ".".repeat(10 - filled), hp, max_hp]
	hp_label.modulate = Color("#DDF5CB") if hp > 34 else Color("#FFBCAB")

func face_target(point: Vector3) -> void:
	var flat_target: Vector3 = Vector3(point.x, global_position.y, point.z)
	if global_position.distance_squared_to(flat_target) > 0.0001:
		look_at(flat_target, Vector3.UP) # Node3D's forward direction is -Z.

func move_to(destination: Vector3) -> void:
	if state == State.DEAD:
		return
	_cancel_move()
	_target = null
	var end: Vector3 = Vector3(destination.x, 0, destination.z)
	face_target(end)
	state = State.MOVING
	_play(&"walk")
	var duration: float = maxf(global_position.distance_to(end) / move_speed, 0.01)
	_move_tween = create_tween()
	_move_tween.tween_property(self, "global_position", end, duration)
	_move_tween.finished.connect(_arrive)

func _arrive() -> void:
	_move_tween = null
	if state == State.DEAD:
		return
	state = State.IDLE
	_play(&"idle")
	arrived.emit()

func attack(target: CozyHero) -> bool:
	if state != State.IDLE or not is_instance_valid(target) or target.state == State.DEAD:
		return false
	if global_position.distance_to(target.global_position) > 1.35:
		return false
	_target = target
	face_target(target.global_position)
	state = State.ATTACKING
	_attack_time = 0.0
	_did_hit = false
	_play(&"attack")
	return true

func take_damage(amount: int) -> void:
	if state == State.DEAD:
		return
	_cancel_move()
	_target = null
	hp = maxi(0, hp - maxi(amount, 0))
	_update_hp()
	if hp == 0:
		state = State.DEAD
		_play(&"death")
		died.emit()
	else:
		state = State.IDLE
		_play(&"hurt")

func play_preview(clip: StringName) -> void:
	_cancel_move()
	_target = null
	hp = max_hp
	_update_hp()
	state = State.DEAD if clip == &"death" else State.IDLE
	_play(clip)

func celebrate() -> void:
	if state == State.DEAD:
		return
	_cancel_move()
	_target = null
	state = State.IDLE
	_play(&"victory")

func _play(clip: StringName) -> void:
	# Apply RESET first so a previous clip cannot leave a limb or tint behind.
	animation_player.play(&"RESET")
	animation_player.advance(0.0)
	animation_player.play(clip)
	animation_player.advance(0.0)

func _animation_finished(clip: StringName) -> void:
	if state != State.DEAD and (clip == &"attack" or clip == &"hurt"):
		state = State.IDLE
		_target = null
		_play(&"idle")

func _cancel_move() -> void:
	if _move_tween != null and _move_tween.is_valid():
		_move_tween.kill()
	_move_tween = null

