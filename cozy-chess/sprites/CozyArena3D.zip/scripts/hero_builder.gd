extends RefCounted
## All geometry is an engine primitive; every moving part has a named pivot.

const HeroScript = preload("res://scripts/hero.gd")

static func build(team_color: Color = Color("#6E8FB5")) -> CozyHero:
	var hero: CozyHero = HeroScript.new()
	hero.name = "Hero"
	var steel: StandardMaterial3D = _material(hero, team_color)
	var gold: StandardMaterial3D = _material(hero, Color("#E8B54A"))
	var red: StandardMaterial3D = _material(hero, Color("#B23A3A"))
	var skin: StandardMaterial3D = _material(hero, Color("#F2C9A0"))
	var dark: StandardMaterial3D = _material(hero, Color("#2A2F3A"))
	var body: Node3D = _pivot(hero, "Body", Vector3.ZERO)
	var hips: Node3D = _pivot(body, "Hips", Vector3(0, 0.53, 0))
	_box(hips, "Belt", Vector3(0.44, 0.07, 0.33), Vector3(0, 0.04, 0), dark)
	_box(hips, "Buckle", Vector3(0.09, 0.08, 0.03), Vector3(0, 0.04, -0.18), gold)
	var torso: Node3D = _pivot(hips, "Torso", Vector3(0, 0.30, 0))
	_box(torso, "Breastplate", Vector3(0.44, 0.45, 0.30), Vector3.ZERO, steel)
	_box(torso, "ChestTrim", Vector3(0.46, 0.04, 0.035), Vector3(0, -0.09, -0.17), gold)
	_box(torso, "TabardTrim", Vector3(0.23, 0.29, 0.035), Vector3(0, -0.29, -0.18), gold)
	_box(torso, "Tabard", Vector3(0.19, 0.25, 0.04), Vector3(0, -0.28, -0.20), red)
	_box(torso, "Scarf", Vector3(0.36, 0.09, 0.34), Vector3(0, 0.22, 0), red)
	var cape: Node3D = _pivot(torso, "Cape", Vector3(0, 0.16, 0.19))
	cape.rotation.x = -0.12
	_box(cape, "Cloth", Vector3(0.47, 0.60, 0.025), Vector3(0, -0.30, 0), red)
	_box(cape, "Hem", Vector3(0.48, 0.035, 0.03), Vector3(0, -0.59, 0), gold)
	var head: Node3D = _pivot(torso, "Head", Vector3(0, 0.44, 0))
	var helmet: SphereMesh = SphereMesh.new()
	helmet.radius = 0.29
	helmet.height = 0.50
	helmet.radial_segments = 12
	helmet.rings = 6
	_mesh(head, "Helmet", helmet, Vector3.ZERO, steel)
	_box(head, "Face", Vector3(0.39, 0.17, 0.04), Vector3(0, -0.02, -0.25), skin)
	_box(head, "Visor", Vector3(0.40, 0.075, 0.035), Vector3(0, 0.005, -0.28), dark)
	_box(head, "EyeL", Vector3(0.055, 0.04, 0.01), Vector3(-0.10, 0.005, -0.303), skin)
	_box(head, "EyeR", Vector3(0.055, 0.04, 0.01), Vector3(0.10, 0.005, -0.303), skin)
	_box(head, "FaceGuard", Vector3(0.43, 0.13, 0.065), Vector3(0, -0.13, -0.25), steel)
	for index: int in range(5):
		_box(head, "Vent%d" % index, Vector3(0.025, 0.075, 0.01), Vector3((index - 2) * 0.075, -0.13, -0.288), dark)
	_box(head, "Brow", Vector3(0.47, 0.035, 0.04), Vector3(0, 0.11, -0.255), gold)
	var crest: PrismMesh = PrismMesh.new()
	crest.size = Vector3(0.10, 0.12, 0.05)
	_mesh(head, "Crest", crest, Vector3(0, 0.16, -0.28), gold)
	for side: int in [-1, 1]:
		var ear: MeshInstance3D = _cylinder(head, "Ear%d" % side, 0.085, 0.04, Vector3(side * 0.285, 0, 0), gold)
		ear.rotation.z = PI / 2.0
	_box(head, "PlumeBase", Vector3(0.09, 0.14, 0.12), Vector3(0, 0.28, 0.02), red)
	_box(head, "PlumeTail", Vector3(0.09, 0.10, 0.19), Vector3(0, 0.27, 0.14), red)
	for side: int in [-1, 1]:
		var suffix: String = "L" if side < 0 else "R"
		var shoulder: Node3D = _pivot(torso, "Shoulder" + suffix, Vector3(side * 0.30, 0.14, 0))
		shoulder.rotation.z = side * 0.12
		_box(shoulder, "Pauldron", Vector3(0.21, 0.15, 0.32), Vector3.ZERO, steel)
		_box(shoulder, "Rim", Vector3(0.22, 0.035, 0.33), Vector3(0, -0.07, 0), gold)
		var arm: Node3D = _pivot(shoulder, "Arm" + suffix, Vector3.ZERO)
		var limb: CapsuleMesh = CapsuleMesh.new()
		limb.radius = 0.085
		limb.height = 0.33
		limb.radial_segments = 8
		limb.rings = 2
		_mesh(arm, "ArmMesh", limb, Vector3(0, -0.17, 0), steel)
		_box(arm, "Gauntlet", Vector3(0.18, 0.16, 0.18), Vector3(0, -0.34, 0), steel)
		_box(arm, "Cuff", Vector3(0.19, 0.035, 0.19), Vector3(0, -0.27, 0), gold)
		var leg: Node3D = _pivot(hips, "Leg" + suffix, Vector3(side * 0.13, -0.07, 0))
		_box(leg, "Greave", Vector3(0.19, 0.30, 0.20), Vector3(0, -0.15, 0), steel)
		_box(leg, "Knee", Vector3(0.20, 0.10, 0.035), Vector3(0, -0.13, -0.115), gold)
		_box(leg, "Boot", Vector3(0.23, 0.14, 0.33), Vector3(0, -0.39, -0.055), steel)
		_box(leg, "BootTrim", Vector3(0.24, 0.035, 0.34), Vector3(0, -0.435, -0.055), gold)
	var left_arm: Node3D = torso.get_node("ShoulderL/ArmL") as Node3D
	var shield: Node3D = _pivot(left_arm, "Shield", Vector3(-0.035, -0.29, -0.16))
	var shield_gold: StandardMaterial3D = _material(hero, Color("#E8B54A"))
	var rim: MeshInstance3D = _cylinder(shield, "GoldRim", 0.27, 0.065, Vector3.ZERO, shield_gold)
	rim.rotation.x = PI / 2.0
	var face: MeshInstance3D = _cylinder(shield, "RedFace", 0.23, 0.025, Vector3(0, 0, -0.045), red)
	face.rotation.x = PI / 2.0
	for index: int in range(8):
		var angle: float = index * TAU / 8.0
		var ray: MeshInstance3D = _box(shield, "SunRay%d" % index, Vector3(0.025, 0.15, 0.02), Vector3(sin(angle) * 0.11, cos(angle) * 0.11, -0.065), shield_gold)
		ray.rotation.z = -angle
	_cylinder(shield, "Boss", 0.065, 0.06, Vector3(0, 0, -0.08), shield_gold).rotation.x = PI / 2.0
	hero.glow_material = shield_gold
	var right_arm: Node3D = torso.get_node("ShoulderR/ArmR") as Node3D
	var sword: Node3D = _pivot(right_arm, "Sword", Vector3(0, -0.34, -0.03))
	sword.rotation.z = PI # Blade points down at rest, up when the arm is raised.
	_cylinder(sword, "Grip", 0.025, 0.12, Vector3.ZERO, dark)
	_box(sword, "Guard", Vector3(0.23, 0.045, 0.07), Vector3(0, 0.065, 0), gold)
	_box(sword, "Blade", Vector3(0.065, 0.34, 0.035), Vector3(0, 0.255, 0), steel)
	var tip: PrismMesh = PrismMesh.new()
	tip.size = Vector3(0.065, 0.10, 0.035)
	_mesh(sword, "Tip", tip, Vector3(0, 0.475, 0), steel)
	_cylinder(sword, "Pommel", 0.04, 0.035, Vector3(0, -0.075, 0), gold)
	return hero

static func _material(hero: CozyHero, color: Color) -> StandardMaterial3D:
	var material: StandardMaterial3D = StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.8
	material.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
	hero.register_material(material)
	return material

static func _pivot(parent: Node3D, node_name: String, pos: Vector3) -> Node3D:
	var pivot: Node3D = Node3D.new()
	pivot.name = node_name
	pivot.position = pos
	parent.add_child(pivot)
	return pivot

static func _mesh(parent: Node3D, node_name: String, mesh: PrimitiveMesh, pos: Vector3, material: StandardMaterial3D) -> MeshInstance3D:
	var instance: MeshInstance3D = MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = pos
	parent.add_child(instance)
	return instance

static func _box(parent: Node3D, node_name: String, size: Vector3, pos: Vector3, material: StandardMaterial3D) -> MeshInstance3D:
	var box: BoxMesh = BoxMesh.new()
	box.size = size
	return _mesh(parent, node_name, box, pos, material)

static func _cylinder(parent: Node3D, node_name: String, radius: float, height: float, pos: Vector3, material: StandardMaterial3D) -> MeshInstance3D:
	var cylinder: CylinderMesh = CylinderMesh.new()
	cylinder.top_radius = radius
	cylinder.bottom_radius = radius
	cylinder.height = height
	cylinder.radial_segments = 12
	return _mesh(parent, node_name, cylinder, pos, material)

