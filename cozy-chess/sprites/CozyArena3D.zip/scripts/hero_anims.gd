extends RefCounted
## Paths are relative to Hero, the AnimationPlayer's root_node.

const BODY: String = "Body"
const HIPS: String = "Body/Hips"
const TORSO: String = "Body/Hips/Torso"
const LEFT: String = "Body/Hips/Torso/ShoulderL"
const RIGHT: String = "Body/Hips/Torso/ShoulderR"
const CAPE: String = "Body/Hips/Torso/Cape"

static func create(hero: Node3D) -> AnimationPlayer:
	var player: AnimationPlayer = AnimationPlayer.new()
	player.name = "AnimationPlayer"
	player.root_node = NodePath("..")
	hero.add_child(player)
	var library: AnimationLibrary = AnimationLibrary.new()
	var animation: Animation
	# This list covers every property animated by any clip.
	var defaults: Dictionary = {
		BODY + ":position:y": 0.0, BODY + ":position:z": 0.0,
		BODY + ":rotation:x": 0.0, TORSO + ":rotation:y": 0.0,
		LEFT + ":rotation:x": 0.0, RIGHT + ":rotation:x": 0.0,
		RIGHT + ":rotation:z": 0.12,
		HIPS + "/LegL:rotation:x": 0.0, HIPS + "/LegR:rotation:x": 0.0,
		CAPE + ":rotation:x": -0.12,
		".:flash_amount": 0.0, ".:fade_amount": 0.0, ".:glow_amount": 0.0
	}
	animation = _clip(library, &"RESET", 0.01, false)
	for path: String in defaults:
		_track(animation, path, [0.0], [defaults[path]])

	animation = _clip(library, &"idle", 2.0)
	_track(animation, BODY + ":position:y", [0.0, 1.0, 2.0], [0.0, 0.025, 0.0])
	_track(animation, CAPE + ":rotation:x", [0.0, 1.0, 2.0], [-0.12, -0.22, -0.12])

	animation = _clip(library, &"walk", 0.6)
	_track(animation, HIPS + "/LegL:rotation:x", [0.0, 0.15, 0.45, 0.6], [0.0, 0.55, -0.55, 0.0])
	_track(animation, HIPS + "/LegR:rotation:x", [0.0, 0.15, 0.45, 0.6], [0.0, -0.55, 0.55, 0.0])
	_track(animation, LEFT + ":rotation:x", [0.0, 0.15, 0.45, 0.6], [0.0, -0.35, 0.35, 0.0])
	_track(animation, RIGHT + ":rotation:x", [0.0, 0.15, 0.45, 0.6], [0.0, 0.35, -0.35, 0.0])
	_track(animation, BODY + ":position:y", [0.0, 0.15, 0.3, 0.45, 0.6], [0.0, 0.045, 0.0, 0.045, 0.0])
	_track(animation, CAPE + ":rotation:x", [0.0, 0.3, 0.6], [-0.2, -0.4, -0.2])

	animation = _clip(library, &"attack", 0.7, false)
	_track(animation, RIGHT + ":rotation:x", [0.0, 0.23, 0.34, 0.48, 0.7], [0.0, -1.15, 1.65, 1.1, 0.0])
	_track(animation, RIGHT + ":rotation:z", [0.0, 0.23, 0.34, 0.7], [0.12, 0.65, -0.3, 0.12])
	_track(animation, TORSO + ":rotation:y", [0.0, 0.23, 0.34, 0.7], [0.0, -0.45, 0.5, 0.0])
	_track(animation, BODY + ":position:z", [0.0, 0.23, 0.34, 0.7], [0.0, 0.08, -0.14, 0.0])

	animation = _clip(library, &"cast", 0.8)
	_track(animation, LEFT + ":rotation:x", [0.0, 0.25, 0.55, 0.8], [0.0, 2.3, 2.3, 0.0])
	_track(animation, ".:glow_amount", [0.0, 0.3, 0.5, 0.8], [0.0, 1.0, 0.35, 0.0])

	animation = _clip(library, &"hurt", 0.3, false)
	_track(animation, BODY + ":rotation:x", [0.0, 0.08, 0.3], [0.0, -0.28, 0.0])
	_track(animation, BODY + ":position:z", [0.0, 0.08, 0.3], [0.0, 0.12, 0.0])
	_track(animation, ".:flash_amount", [0.0, 0.04, 0.12, 0.3], [0.0, 1.0, 0.7, 0.0])

	animation = _clip(library, &"victory", 1.2)
	_track(animation, BODY + ":position:y", [0.0, 0.18, 0.45, 0.7, 1.2], [0.0, 0.0, 0.34, 0.0, 0.0])
	_track(animation, RIGHT + ":rotation:x", [0.0, 0.25, 0.8, 1.2], [0.0, 2.7, 2.7, 0.0])
	_track(animation, CAPE + ":rotation:x", [0.0, 0.45, 0.8, 1.2], [-0.12, -0.65, -0.2, -0.12])

	animation = _clip(library, &"death", 1.0, false)
	_track(animation, BODY + ":rotation:x", [0.0, 0.55, 1.0], [0.0, -PI / 2.0, -PI / 2.0])
	_track(animation, BODY + ":position:y", [0.0, 0.55, 1.0], [0.0, 0.10, -0.25])
	_track(animation, BODY + ":position:z", [0.0, 0.55, 1.0], [0.0, 0.25, 0.25])
	_track(animation, ".:fade_amount", [0.0, 0.55, 1.0], [0.0, 0.0, 1.0])
	player.add_animation_library(&"", library)
	return player

static func _clip(library: AnimationLibrary, clip_name: StringName, duration: float, looping: bool = true) -> Animation:
	var animation: Animation = Animation.new()
	animation.length = duration
	animation.loop_mode = Animation.LOOP_LINEAR if looping else Animation.LOOP_NONE
	library.add_animation(clip_name, animation)
	return animation

static func _track(animation: Animation, path: String, times: Array[float], values: Array) -> void:
	var track: int = animation.add_track(Animation.TYPE_VALUE)
	animation.track_set_path(track, NodePath(path))
	animation.track_set_interpolation_type(track, Animation.INTERPOLATION_LINEAR)
	for index: int in range(times.size()):
		animation.track_insert_key(track, times[index], values[index])

